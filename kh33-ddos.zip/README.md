<p align="center"><img src="./icon/mcbot.ico" width="150px" height="150px" alt="mcbot"></p>
<h1 align="center">DDoS attack minecraft servers with 24 Method</h1>


## Methods
```💣 Methods:
bigpacket
botjoiner
doublejoin
emptypacket
gayspam
handshake
invaliddata
invalidspoof
invalidnames
spoof
join
legacyping
legitnamejoin
localhost
pingjoin
longhost
longnames
nullping
ping
query
randompacket
bighandshake
unexpectedpacket
memory
test
bigpacket
botjoiner
doublejoin
emptypacket
gayspam
handshake
invaliddata
invalidspoof
invalidnames
spoof
join
legacyping
legitnamejoin
localhost
pingjoin
longhost
longnames
nullping
ping
query
randompacket
bighandshake
unexpectedpacket
memory
```